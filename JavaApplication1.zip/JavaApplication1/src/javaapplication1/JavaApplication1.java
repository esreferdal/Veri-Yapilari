package javaapplication1;

import java.util.Scanner;

public class JavaApplication1 {

  
    public static void main(String[] args) {
        
        int i;
        int dizi[] = new int[10];
        Scanner sc = new Scanner(System.in);
 
        System.out.print("10 tane sayı girin :");
 
        for (i = 0; i < dizi.length; i++) {
            dizi[i] = sc.nextInt();
        }
 
  
        for (int sayi:dizi) {
            System.out.print(sayi+" ,");
        }
        System.out.print("evet dizi min heap yapısında :");
    }
    private final int heapMaxSize;
  
    
    class MinHeap {
    public int[] heapData;
    private int sizeOfHeap;
    private int heapMaxSize;

    private static final int FRONT = 1;

    public MinHeap(int heapMaxSize) {
         this.heapMaxSize = heapMaxSize;
         this.sizeOfHeap = 0;
         heapData = new int[this.heapMaxSize + 1];
            heapData[0] = Integer.MIN_VALUE;
    }   


    private void swap(int firstNode, int secondNode) {
        int temp;
         temp = heapData[firstNode];
         heapData[firstNode] = heapData[secondNode];
         heapData[secondNode] = temp;
    }

    private void minHeapify(int position) {

         if (!checkLeaf(position)) {
              if (heapData[position] > heapData[getLeftChildPosition(position)] || heapData[position] > heapData[getRightChildPosition(position)]) {

                 if (heapData[getLeftChildPosition(position)] < heapData[getRightChildPosition(position)]) {
                     swap(position, getLeftChildPosition(position));
                     minHeapify(getLeftChildPosition(position));
                }
                else {
                      swap(position, getRightChildPosition(position));
                       minHeapify(getRightChildPosition(position));
                }
            }
        }
    }

    public void insertNode(int data) {
            if (sizeOfHeap >= heapMaxSize) {
            return;
        }
         heapData[++sizeOfHeap] = data;
            int current = sizeOfHeap;

            while (heapData[current] < heapData[getParentPosition(current)]) {
              swap(current, getParentPosition(current));
              current = getParentPosition(current);
        }
    }

    public void displayHeap() {
        System.out.println("ana düğüm" + "\t" + "sol çocuk düğüm" + "\t\t" + "sağ çocuk düğüm");
          for (int k = 1; k <= sizeOfHeap / 2; k++) {
              System.out.print("\t " + heapData[k] + "\t\t\t\t" + heapData[2 * k] + "\t\t\t\t\t" + heapData[2 * k + 1]);
            System.out.println();
        }
    }

    public void designMinHeap() {
          for (int position = (sizeOfHeap / 2); position >= 1; position--) {
            minHeapify(position);
        }
    }
}

class MinHeap {


    public static void main(String[] arg) {
        int heapSize;

        Scanner sc = new Scanner(System.in);

        System.out.println("Min Yığın boyutunu girin");
        heapSize = sc.nextInt();

         MinHeap heapObj = new MinHeap(heapSize);

        for (int i = 1; i <= heapSize; i++) {
            System.out.print(+i + "." + " elementi gir: ");
            int data = sc.nextInt();
               heapObj.insertNode(data);
        }

        sc.close();
         heapObj.designMinHeap();

        System.out.println("Minimum Yığın ");
            heapObj.displayHeap();


    }
}



 
